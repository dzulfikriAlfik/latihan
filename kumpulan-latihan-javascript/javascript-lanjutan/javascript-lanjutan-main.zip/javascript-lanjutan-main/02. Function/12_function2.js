// ~ contoh 1 ~
// var a = 8;
// var b = 3;
// var volumeA;
// var volumeB;
// var total;

// volumeA = a * a * a;
// volumeB = b * b * b;

// total = volumeA + volumeB;

// console.log(total);
// ~ end contoh 1 ~



// ~ contoh 4 ~
function jumlahVolumeDuaKubus(a, b) {
	var a = 8;
	var b = 3;

	volumeA = a * a * a;
	volumeB = b * b * b;

	total = volumeA + volumeB;

	return total;
}

alert(jumlahVolumeDuaKubus(8, 3));
// ~ end contoh 4 ~