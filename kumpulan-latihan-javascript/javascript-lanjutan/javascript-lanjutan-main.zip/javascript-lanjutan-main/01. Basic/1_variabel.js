// ~ VARIABEL ~
var x = 10;
console.log('hello world');
console.log('isi dari variable x adalah ' + x);
// ~ end VARIABEL ~


// ~ POP UP BOX ~
// var nama = prompt('masukan nama anda');
// confirm('apakah anda yakin');
// alert('nama anda adalah ' + nama);



// alert('Mulai');
// for(var i = 1; i <= 5; i++) {
//   alert('Hello World! ' + i);
// }
// alert('Selesai');



// var angka = prompt('masukan angka :');
// if( angka % 2 === 0 ) {
//   alert(angka + ' adalah bilangan GENAP');
// }else {
//   alert(angka + ' adalah bilangan GANJIL');
// }
// ~ end POP UP BOX ~