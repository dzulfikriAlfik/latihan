// ~ contoh 1 ~
var angka = prompt('Masukan Angka');

if (angka % 2 === 0) {
	alert(angka + ' adalah bilangan GENAP');
} else if (angka % 2 === 1) {
	alert(angka + ' adalah bilangan GANJIL');
} else {
	alert('Yang anda masukan bukan angka!');
}
// ~ end contoh 1 ~