// ~ contoh 1 ~
// var nilaiAwal = 1;

// while(nilaiAwal <= 5) {
// 	console.log('hello world!');
// 	nilaiAwal++;
// }
// ~ end contoh 1 ~



// ~ contoh 2 ~
var nilaiAwal = 1;

while(nilaiAwal <= 5) {
	console.log('hello world! ' + nilaiAwal + ' x');
	nilaiAwal++;
}
// ~ end contoh 2 ~