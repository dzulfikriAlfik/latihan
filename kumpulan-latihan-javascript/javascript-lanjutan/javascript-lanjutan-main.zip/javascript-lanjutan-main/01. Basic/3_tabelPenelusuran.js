// ~ contoh 1 ~
// var nilaiAwal = 1;

// while(nilaiAwal <= 10) {
// 	console.log('Angkot No. ' + nilaiAwal + ' beroperasi dengan baik.');
// 	nilaiAwal++;
// }
// ~ end contoh 1 ~



// ~ contoh 2 ~
var jmlAngkot = 10;
var noAngkot = 1;

while(noAngkot <= jmlAngkot) {
	console.log('Angkot No. ' + noAngkot + ' beroperasi dengan baik.');
	noAngkot++;
}
// ~ end contoh 2 ~